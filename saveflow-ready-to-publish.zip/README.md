# SaveFlow — Ready to Deploy

## Deploy
Upload this repository to a Git provider and deploy it as a Docker web service.
The included `render.yaml` is prepared for Render.

## Local
Requirements: Docker.
`docker build -t saveflow .`
`docker run -p 3000:3000 saveflow`

Open http://localhost:3000

## Notes
- Downloads only publicly accessible URLs supported by yt-dlp.
- No downloader can guarantee every platform or every video; platform changes, login requirements, DRM, age restrictions, or private content can prevent downloads.
- Users should only download content they have permission to save and comply with each platform's terms and applicable law.
