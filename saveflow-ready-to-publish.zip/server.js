import express from "express";
import { spawn } from "node:child_process";
import { existsSync, mkdirSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import crypto from "node:crypto";
import fs from "node:fs";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 3000;
const TMP = "/tmp/saveflow";
if (!existsSync(TMP)) mkdirSync(TMP, {recursive:true});

app.use(express.json({limit:"20kb"}));
app.use(express.static(path.join(__dirname,"public")));

const allowed = [
  "tiktok.com","vm.tiktok.com","youtube.com","youtu.be",
  "instagram.com","facebook.com","fb.watch","pinterest.com","pin.it"
];

function validUrl(raw){
  try {
    const u = new URL(raw);
    if (!["http:","https:"].includes(u.protocol)) return false;
    return allowed.some(d => u.hostname === d || u.hostname.endsWith("."+d));
  } catch { return false; }
}

app.post("/api/download", (req,res)=>{
  const url = String(req.body?.url || "").trim();
  if (!validUrl(url)) return res.status(400).json({error:"URL tidak didukung."});

  const id = crypto.randomBytes(10).toString("hex");
  const output = path.join(TMP, `${id}.%(ext)s`);
  const args = [
    "--no-playlist",
    "--no-warnings",
    "-f","bv*+ba/b",
    "--merge-output-format","mp4",
    "-o",output,
    url
  ];

  const child = spawn("yt-dlp", args, {stdio:["ignore","pipe","pipe"]});
  let stderr="";
  child.stderr.on("data", d => stderr += d.toString());

  child.on("close", code => {
    if (code !== 0) return res.status(500).json({error:"Video gagal diproses. Pastikan link publik dan masih tersedia."});
    const files = requireFiles(TMP, id);
    if (!files.length) return res.status(500).json({error:"File hasil download tidak ditemukan."});
    const file = files[0];
    res.download(file, path.basename(file), err => {
      try { if (existsSync(file)) fs.unlinkSync(file); } catch {}
      if (err && !res.headersSent) res.status(500).end();
    });
  });
});

function requireFiles(dir,id){
  return fs.readdirSync(dir).filter(x=>x.startsWith(id+".")).map(x=>path.join(dir,x));
}

// ESM-compatible fs access


app.get("/health",(req,res)=>res.json({ok:true}));
app.listen(PORT,()=>console.log(`SaveFlow running on ${PORT}`));
